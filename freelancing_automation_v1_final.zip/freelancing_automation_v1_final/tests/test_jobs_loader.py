from __future__ import annotations

from pathlib import Path

from src.jobs_loader import load_jobs, JobLoadError


def test_load_example_file() -> None:
    here = Path(__file__).resolve().parent
    root = here.parent
    data_path = root / "data" / "jobs_input_example.json"
    jobs = load_jobs(data_path)
    assert len(jobs) >= 2
    assert jobs[0].id
    assert jobs[0].title
    assert jobs[0].platform


def test_invalid_json(tmp_path) -> None:
    bad = tmp_path / "bad.json"
    bad.write_text("{not valid json}")
    try:
        load_jobs(bad)
    except JobLoadError:
        pass
    else:
        raise AssertionError("Expected JobLoadError for invalid JSON")
