from __future__ import annotations

from src.jobs_loader import load_jobs
from src.jobs_scorer import score_jobs, sort_scored_jobs


def test_scoring_and_sorting() -> None:
    jobs = load_jobs("data/jobs_input_example.json")
    scored = score_jobs(jobs)
    assert len(scored) == len(jobs)

    sorted_scored = sort_scored_jobs(scored)
    assert sorted_scored[0].score >= sorted_scored[-1].score
