# Freelancing Automation – V1 (Job Scanner)

This is V1 of your freelancing automation system.

Goal of V1:
- Take a small JSON file of jobs (exported from Upwork/Guru/etc.).
- Score each job based on your preferences.
- Print a **shortlist** of the best jobs in the terminal.
- Save that shortlist to `output/shortlist.json`.

Designed for:
- **Python 3.10+**
- Works on **Android Termux** (pure standard library, no external packages).

## 1. Install & Run (Termux or any Linux)

```bash
# 1) Go inside the project
cd freelancing_automation_v1_final

# 2) (Optional) Create venv
python -m venv .venv
source .venv/bin/activate

# 3) Run on the example data
python -m src.jobs_shortlist_cli \
  --input data/jobs_input_example.json \
  --output output/shortlist.json \
  --top-n 5
```

The script will:
- Read jobs from JSON
- Score them
- Print a human-readable shortlist
- Save the top jobs to `output/shortlist.json`

## 2. Input JSON format

`data/jobs_input_example.json` shows the expected structure:

```json
[
  {
    "id": "upwork-123",
    "platform": "upwork",
    "title": "Convert PDF to fillable Word form",
    "description": "Need a 10-page disclosure form converted into a true fillable PDF in Acrobat...",
    "budget": 40,
    "currency": "USD",
    "is_hourly": false,
    "connects_required": 8,
    "proposals": 15,
    "has_attachments": true,
    "skills": ["PDF", "Acrobat", "Form Development"]
  }
]
```

You can export jobs from any source, manually or via another script/agent, and normalize them into this format.

## 3. Scoring logic (short version)

The scoring is intentionally **simple but transparent**:

- +25 points – Job has at least one attachment (you like file-based jobs).
- +15 points – Fixed-price (you said you prefer this).
- +0 .. +20 points – Budget: 0–20 scaled from 0–100 USD.
- +15 points – "sweet spot" competition: proposals between 5 and 20.
- -15 points – proposals > 40 (too crowded).
- +10 points – title/description mentions any of your **core skills**:
  - "pdf", "fillable", "acrobat", "form"
  - "powerpoint", "slide", "deck", "pitch"
  - "word", "docx", "formatting", "template"
- -30 points – red-flag keywords (exam cheating, scammy stuff).
- +5 points – client posted attachments and budget > 0 (slightly more serious).

This is **V1**: nothing is hard-coded to Upwork only. Any platform can be used as long as the JSON fields match.

## 4. Files

- `src/jobs_model.py` – dataclasses & types for Job.
- `src/jobs_loader.py` – read & validate JSON.
- `src/jobs_scorer.py` – scoring logic for jobs.
- `src/jobs_shortlist_cli.py` – CLI entry point.
- `tests/` – basic tests that run without external tools.
- `verification/*.md` – human-readable 7-layer verification notes.

## 5. 7-layer checking (practical)

Inside `verification/` each main file has a short checklist that was applied:

1. **Syntax** – file imports & runs without syntax errors.
2. **Type-shape sanity** – basic assumptions about dict keys & types.
3. **Edge cases** – empty list, missing optional fields.
4. **Logic sanity** – scoring & filters match your preferences.
5. **I/O sanity** – CLI reads input and writes output where expected.
6. **Termux safety** – no non-standard imports, no OS-specific paths.
7. **Failure behavior** – nice error messages instead of crashes.

I’ve run the Python files here in a Linux-like environment; Termux should behave the same if Python 3.10+ is installed.

If something still breaks in your environment, you can paste the error into ChatGPT and we’ll fix that specific issue.
