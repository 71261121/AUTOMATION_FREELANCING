# Freelancing Automation – v4 (Gold Tier)

This is **v4 (gold level)** of your freelancing job‑shortlisting engine, designed for Termux on Android.

## What this version adds vs v3

- Uses a **profile config** (`config/profile_v4.json`) to:
  - Set your core skills
  - Define preferred platforms
  - Define minimum budget and max connects you want to spend
  - Add positive keywords and red‑flag keywords
- Each job is classified into:
  - `fit_level`: `"high" | "medium" | "low"`
  - `risk_level`: `"normal" | "red_flag"`
  - `action`: `"apply_now" | "watchlist" | "skip"`
- CLI output is still simple text + JSON, but now includes:
  - Score + reasons (like before)
  - Fit level, risk, and action hint so you know *why* it was shortlisted.

## Basic usage

From the project root (this folder):

```bash
python -m src.jobs_shortlist_cli   --input data/jobs_input_example.json   --output output/shortlist_v4.json   --top-n 5   --profile config/profile_v4.json
```

- Edit `config/profile_v4.json` to match your real preferences.
- Edit `data/jobs_input_example.json` with real jobs scraped/copied from Upwork / Guru etc.
