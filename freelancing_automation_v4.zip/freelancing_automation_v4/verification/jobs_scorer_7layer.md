# 7‑Layer Verification – jobs_scorer

1. **Intent layer** – File purpose is clearly defined and matches the v4 blueprint.
2. **Interface layer** – Public functions/classes have stable names and simple signatures.
3. **Logic layer** – Control flow and scoring/loader logic checked for edge cases.
4. **Data layer** – JSON I/O and types validated on example data.
5. **Termux layer** – No OS‑specific paths; standard Python 3 only.
6. **Safety layer** – No network calls, no credentials, no scraping logic.
7. **Test layer** – Covered by `pytest` tests for basic behaviour and red‑flag handling.
