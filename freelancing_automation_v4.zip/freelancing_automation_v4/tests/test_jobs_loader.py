import json
from src.jobs_loader import load_jobs, JobLoadError
from src.jobs_model import Job


def test_load_jobs_basic(tmp_path):
    data = [
        {
            "url": "http://example.com",
            "id": "job-1",
            "platform": "upwork",
            "title": "Test job",
            "description": "Some description",
            "budget": 50,
            "currency": "USD",
            "is_hourly": False,
            "connects_required": 6,
            "proposals": 10,
            "has_attachments": True,
            "skills": ["PDF"],
        }
    ]
    p = tmp_path / "jobs.json"
    p.write_text(json.dumps(data), encoding="utf-8")

    jobs = load_jobs(str(p))
    assert len(jobs) == 1
    assert isinstance(jobs[0], Job)
    assert jobs[0].title == "Test job"


def test_load_jobs_bad_file_raises(tmp_path):
    p = tmp_path / "jobs.json"
    p.write_text("not json", encoding="utf-8")
    try:
        load_jobs(str(p))
    except JobLoadError:
        return
    assert False, "Expected JobLoadError"
