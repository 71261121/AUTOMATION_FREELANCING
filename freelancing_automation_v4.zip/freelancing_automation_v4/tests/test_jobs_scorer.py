from src.jobs_model import Job
from src.jobs_scorer import Profile, score_job


def _dummy_profile() -> Profile:
    return Profile(
        min_budget_usd=50.0,
        max_connects=10,
        preferred_platforms={"upwork": 4, "guru": 4},
        core_skills=["pdf", "word"],
        bonus_keywords=["deck"],
        red_flag_keywords=["exam"],
        min_score_apply=70.0,
        min_score_watch=50.0,
    )


def test_score_job_sets_basic_fields():
    job = Job(
        url="u",
        id="1",
        platform="upwork",
        title="Convert PDF",
        description="deck work",
        budget=80.0,
        currency="USD",
        is_hourly=False,
        connects_required=6,
        proposals=10,
        has_attachments=True,
        skills=["PDF"],
    )
    profile = _dummy_profile()
    scored = score_job(job, profile)
    assert scored.score != 0
    assert scored.fit_level in ("high", "medium", "low")
    assert scored.risk_level in ("normal", "red_flag")
    assert scored.action in ("apply_now", "watchlist", "skip")


def test_red_flag_for_exam():
    job = Job(
        url="u",
        id="2",
        platform="upwork",
        title="Help with exam answers",
        description="university exam help",
        budget=100.0,
        currency="USD",
        is_hourly=True,
        connects_required=4,
        proposals=5,
        has_attachments=False,
        skills=["Writing"],
    )
    profile = _dummy_profile()
    scored = score_job(job, profile)
    assert scored.risk_level == "red_flag"
    assert scored.action == "skip"
