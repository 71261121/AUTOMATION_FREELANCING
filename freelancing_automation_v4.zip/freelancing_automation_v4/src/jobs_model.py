from __future__ import annotations

from dataclasses import dataclass
from typing import List, Dict, Any


@dataclass
class Job:
    """Single freelancing job posting.

    This is intentionally small and stable so later versions (v4+)
    can reuse it without breaking v3.
    """

    url: str
    id: str
    platform: str  # e.g., "upwork", "guru"
    title: str
    description: str
    budget: float
    currency: str
    is_hourly: bool
    connects_required: int
    proposals: int
    has_attachments: bool
    skills: List[str]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "url": self.url,
            "id": self.id,
            "platform": self.platform,
            "title": self.title,
            "description": self.description,
            "budget": self.budget,
            "currency": self.currency,
            "is_hourly": self.is_hourly,
            "connects_required": self.connects_required,
            "proposals": self.proposals,
            "has_attachments": self.has_attachments,
            "skills": list(self.skills),
        }
