from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Dict, Any


@dataclass
class Job:
    url: str
    id: str
    platform: str
    title: str
    description: str
    budget: float
    currency: str
    is_hourly: bool
    connects_required: int
    proposals: int
    has_attachments: bool
    skills: List[str] = field(default_factory=list)

    # computed fields (v4)
    score: float = 0.0
    reasons: List[str] = field(default_factory=list)
    fit_level: str = "low"      # high / medium / low
    risk_level: str = "normal"  # normal / red_flag
    action: str = "skip"        # apply_now / watchlist / skip

    @staticmethod
    def from_dict(data: Dict[str, Any]) -> "Job":
        """Create a Job from a loose dict. Missing keys fall back to safe defaults."""
        return Job(
            url=str(data.get("url", "")),
            id=str(data.get("id", "")),
            platform=str(data.get("platform", "")).lower(),
            title=str(data.get("title", "")),
            description=str(data.get("description", "")),
            budget=float(data.get("budget", 0.0) or 0.0),
            currency=str(data.get("currency", "USD")),
            is_hourly=bool(data.get("is_hourly", False)),
            connects_required=int(data.get("connects_required", 0) or 0),
            proposals=int(data.get("proposals", 0) or 0),
            has_attachments=bool(data.get("has_attachments", False)),
            skills=[str(s) for s in data.get("skills", [])],
        )

    def to_dict(self) -> Dict[str, Any]:
        """Return a JSON‑serialisable dict with both base and computed fields."""
        return {
            "url": self.url,
            "id": self.id,
            "platform": self.platform,
            "title": self.title,
            "description": self.description,
            "budget": self.budget,
            "currency": self.currency,
            "is_hourly": self.is_hourly,
            "connects_required": self.connects_required,
            "proposals": self.proposals,
            "has_attachments": self.has_attachments,
            "skills": list(self.skills),
            "score": self.score,
            "reasons": list(self.reasons),
            "fit_level": self.fit_level,
            "risk_level": self.risk_level,
            "action": self.action,
        }
