from __future__ import annotations

import json
from typing import List

from .jobs_model import Job


class JobLoadError(Exception):
    """Raised when the JSON input is invalid or cannot be parsed into jobs."""


def _coerce_float(value, field_name: str) -> float:
    try:
        return float(value)
    except (TypeError, ValueError) as exc:
        raise JobLoadError(f"Invalid numeric value for '{field_name}': {value!r}") from exc


def _coerce_int(value, field_name: str) -> int:
    try:
        return int(value)
    except (TypeError, ValueError) as exc:
        raise JobLoadError(f"Invalid integer value for '{field_name}': {value!r}") from exc


def load_jobs(path: str) -> List[Job]:
    """Load jobs from a JSON file.

    Expected structure:
      [
        {
          "url": "...",
          "id": "...",
          "platform": "upwork" | "guru" | "...",
          "title": "...",
          "description": "...",
          "budget": 50.0,
          "currency": "USD",
          "is_hourly": false,
          "connects_required": 8,
          "proposals": 12,
          "has_attachments": true,
          "skills": ["PowerPoint", "Pitch Deck"]
        },
        ...
      ]
    """
    try:
        with open(path, "r", encoding="utf-8") as f:
            raw = json.load(f)
    except FileNotFoundError as exc:
        raise JobLoadError(f"Input file not found: {path}") from exc
    except json.JSONDecodeError as exc:
        raise JobLoadError(f"Invalid JSON in input file: {path}") from exc

    if not isinstance(raw, list):
        raise JobLoadError("Top-level JSON must be a list of jobs")

    jobs: List[Job] = []
    for idx, item in enumerate(raw):
        if not isinstance(item, dict):
            raise JobLoadError(f"Job at index {idx} is not an object")

        try:
            job = Job(
                url=str(item.get("url", "")),
                id=str(item.get("id", f"job-{idx}")),
                platform=str(item.get("platform", "unknown")),
                title=str(item.get("title", "")),
                description=str(item.get("description", "")),
                budget=_coerce_float(item.get("budget", 0.0), "budget"),
                currency=str(item.get("currency", "USD")),
                is_hourly=bool(item.get("is_hourly", False)),
                connects_required=_coerce_int(item.get("connects_required", 0), "connects_required"),
                proposals=_coerce_int(item.get("proposals", 0), "proposals"),
                has_attachments=bool(item.get("has_attachments", False)),
                skills=[str(s) for s in (item.get("skills") or [])],
            )
        except JobLoadError:
            raise
        except Exception as exc:  # defensive: don't let a surprise shape crash the run
            raise JobLoadError(f"Failed to parse job at index {idx}: {exc}") from exc

        jobs.append(job)

    return jobs
