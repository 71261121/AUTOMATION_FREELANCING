from __future__ import annotations

import json
from typing import List

from .jobs_model import Job


class JobLoadError(Exception):
    """Raised when jobs cannot be loaded correctly."""
    pass


def load_jobs(path: str) -> List[Job]:
    """Load jobs from a JSON file.

    The file is expected to contain a list of dicts, but we are lenient:
    - If the root is a dict with a top‑level "jobs" key, we use that.
    - Bad entries are skipped instead of crashing.
    """
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except FileNotFoundError as e:
        raise JobLoadError(f"Input file not found: {path}") from e
    except json.JSONDecodeError as e:
        raise JobLoadError(f"Invalid JSON in input file: {path}") from e

    if isinstance(data, dict):
        # allow {"jobs": [...]} shape as well
        data = data.get("jobs", [])

    if not isinstance(data, list):
        raise JobLoadError("Input JSON must be a list of jobs or an object with a 'jobs' list.")

    jobs: List[Job] = []
    for idx, raw in enumerate(data):
        if not isinstance(raw, dict):
            # skip weird entries, but keep going
            continue
        try:
            job = Job.from_dict(raw)
            jobs.append(job)
        except Exception:
            # If something is badly malformed, skip that entry only
            continue

    return jobs
