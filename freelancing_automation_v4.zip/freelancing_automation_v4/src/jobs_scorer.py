from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Tuple

from .jobs_model import Job


@dataclass
class Profile:
    min_budget_usd: float
    max_connects: int
    preferred_platforms: Dict[str, float]
    core_skills: List[str]
    bonus_keywords: List[str]
    red_flag_keywords: List[str]
    min_score_apply: float
    min_score_watch: float


def load_profile(path: str) -> Profile:
    import json

    with open(path, "r", encoding="utf-8") as f:
        cfg = json.load(f)

    return Profile(
        min_budget_usd=float(cfg.get("min_budget_usd", 0.0)),
        max_connects=int(cfg.get("max_connects", 999)),
        preferred_platforms={str(k).lower(): float(v) for k, v in cfg.get("preferred_platforms", {}).items()},
        core_skills=[str(s).lower() for s in cfg.get("core_skills", [])],
        bonus_keywords=[str(s).lower() for s in cfg.get("bonus_keywords", [])],
        red_flag_keywords=[str(s).lower() for s in cfg.get("red_flag_keywords", [])],
        min_score_apply=float(cfg.get("min_score_apply", 0.0)),
        min_score_watch=float(cfg.get("min_score_watch", 0.0)),
    )


def _score_budget(budget: float) -> float:
    # Same behaviour style as earlier versions:
    # approx 0.2 points per USD, capped at +20.
    if budget <= 0:
        return 0.0
    score = budget * 0.2
    return min(score, 20.0)


def _score_proposals(count: int) -> float:
    # healthy band 5–20
    if 5 <= count <= 20:
        return 15.0
    if count > 40:
        return -5.0
    return 0.0


def _score_core_skills(job: Job, profile: Profile) -> Tuple[float, int]:
    job_skills_lower = [s.lower() for s in job.skills]
    hits = sum(1 for s in job_skills_lower if s in profile.core_skills)
    # 4 points per hit up to 5 hits (max 20)
    score = min(hits * 4.0, 20.0)
    return score, hits


def _score_bonus_keywords(text: str, profile: Profile) -> Tuple[float, int]:
    text_l = text.lower()
    hits = 0
    for kw in profile.bonus_keywords:
        if kw and kw in text_l:
            hits += 1
    # 2 points per hit, capped at 10
    score = min(hits * 2.0, 10.0)
    return score, hits


def _detect_red_flags(text: str, profile: Profile) -> bool:
    text_l = text.lower()
    for kw in profile.red_flag_keywords:
        if kw and kw in text_l:
            return True
    return False


def score_job(job: Job, profile: Profile) -> Job:
    """Compute score, reasons, fit_level, risk_level and action for a single job."""
    reasons: List[str] = []
    score = 0.0
    text = f"{job.title} {job.description}"

    # Attachments
    if job.has_attachments:
        score += 25.0
        reasons.append("+25: has attachment(s)")

    # Fixed vs hourly
    if job.is_hourly:
        score += 5.0
        reasons.append("+5: hourly job (kept neutral)")
    else:
        score += 15.0
        reasons.append("+15: fixed-price job")

    # Budget
    b_score = _score_budget(job.budget)
    if b_score:
        score += b_score
        reasons.append(f"+{b_score:.1f}: budget-based score (budget={job.budget:.1f})")

    # Proposals
    p_score = _score_proposals(job.proposals)
    if p_score:
        if p_score > 0:
            reasons.append("+15: healthy competition (5-20 proposals)")
        else:
            reasons.append(f"{p_score:.0f}: too many proposals")
        score += p_score

    # Core skills
    core_score, core_hits = _score_core_skills(job, profile)
    if core_score:
        reasons.append(f"+{core_score:.0f}: matches your core skills ({core_hits} hits)")
        score += core_score

    # Bonus keywords (title + description)
    bonus_score, bonus_hits = _score_bonus_keywords(text, profile)
    if bonus_score:
        reasons.append(f"+{bonus_score:.0f}: bonus keyword matches ({bonus_hits} hits)")
        score += bonus_score

    # Platform preference
    plat_bonus = profile.preferred_platforms.get(job.platform.lower(), 0.0)
    if plat_bonus:
        score += plat_bonus
        reasons.append(f"+{plat_bonus:.0f}: preferred platform")

    # Connects penalty
    if job.connects_required > profile.max_connects:
        score -= 8.0
        reasons.append(f"-8: above your max connects ({profile.max_connects})")

    # Minimum budget penalty
    if job.budget < profile.min_budget_usd:
        score -= 10.0
        reasons.append(f"-10: below your minimum budget ({profile.min_budget_usd:.1f})")

    # Red flag detection
    red = _detect_red_flags(text, profile)
    if red:
        score -= 30.0
        reasons.append("-30: red-flag keyword detected")
        risk_level = "red_flag"
    else:
        risk_level = "normal"

    # Fit level
    if score >= profile.min_score_apply and core_hits >= 2 and not red:
        fit_level = "high"
    elif score >= profile.min_score_watch and not red:
        fit_level = "medium"
    else:
        fit_level = "low"

    # Action based on fit + risk + budget/connects
    if risk_level == "red_flag":
        action = "skip"
    elif fit_level == "high" and job.budget >= profile.min_budget_usd and job.connects_required <= profile.max_connects:
        action = "apply_now"
    elif fit_level in ("high", "medium"):
        action = "watchlist"
    else:
        action = "skip"

    job.score = round(score, 1)
    job.reasons = reasons
    job.fit_level = fit_level
    job.risk_level = risk_level
    job.action = action
    return job
