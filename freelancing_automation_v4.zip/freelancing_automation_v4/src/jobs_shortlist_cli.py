from __future__ import annotations

import argparse
import json
from typing import Any, Dict, List

from .jobs_loader import load_jobs, JobLoadError
from .jobs_scorer import score_job


def _load_profile(path: str | None) -> Dict[str, Any]:
    if not path:
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        raise SystemExit(f"Profile file not found: {path}")
    except json.JSONDecodeError:
        raise SystemExit(f"Invalid JSON in profile file: {path}")


def main(argv: List[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description="Shortlist freelancing jobs based on profile scoring.")
    parser.add_argument("--input", required=True, help="Path to input jobs JSON file")
    parser.add_argument("--output", required=True, help="Path to write shortlisted jobs JSON file")
    parser.add_argument("--top-n", type=int, default=5, help="Number of top jobs to keep")
    parser.add_argument("--profile", required=False, help="Optional path to profile JSON config")

    args = parser.parse_args(argv)

    try:
        jobs = load_jobs(args.input)
    except JobLoadError as exc:
        raise SystemExit(str(exc)) from exc

    profile = _load_profile(args.profile)

    hard_filters = {}
    if isinstance(profile, dict):
        hard_filters = profile.get("hard_filters", {}) or {}

    scored = []
    for job in jobs:
        score, reasons = score_job(job, profile=profile)

        text = f"{job.title} {job.description}".lower()

        # v4 hard filters applied at CLI level
        if hard_filters.get("require_attachments") and not job.has_attachments:
            reasons.append("hard-filter: dropped because attachment is required by profile")
            score = -999.0

        if hard_filters.get("discard_exam_like") and "exam" in text:
            reasons.append("hard-filter: dropped exam-like job based on profile")
            score = -999.0

        scored.append((score, reasons, job))

    # v4: drop clearly bad fits (negative scores) before sorting
    scored = [item for item in scored if item[0] > 0]

    # Sort descending by score
    scored.sort(key=lambda t: t[0], reverse=True)
    top_n = max(1, int(args.top_n))
    shortlisted = scored[:top_n]

    print("========== SHORTLIST ==========")
    for rank, (score, reasons, job) in enumerate(shortlisted, start=1):
        print()
        print(f"--- #{rank} ---")
        print(f"Score: {score:.1f}")
        print(f"Title: {job.title}")
        print(f"Platform: {job.platform}")
        print(f"Budget: {job.budget} {job.currency}")
        print(f"Proposals: {job.proposals}")
        print(f"Connects required: {job.connects_required}")
        print(f"Attachments: {'yes' if job.has_attachments else 'no'}")
        print(f"ID: {job.id}")
        print(f"URL: {job.url}")
        print("Reasons:")
        for r in reasons:
            print(f"  - {r}")

    # Write JSON output
    output_jobs = [job.to_dict() for _, _, job in shortlisted]
    try:
        with open(args.output, "w", encoding="utf-8") as f:
            json.dump(output_jobs, f, indent=2)
    except OSError as exc:
        raise SystemExit(f"Failed to write output file: {exc}") from exc

    print()
    print(f"Shortlist saved to: {args.output}")


if __name__ == "__main__":
    main()
