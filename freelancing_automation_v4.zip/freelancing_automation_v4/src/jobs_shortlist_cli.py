from __future__ import annotations

import argparse
import json
from typing import List

from .jobs_loader import load_jobs, JobLoadError
from .jobs_scorer import load_profile, score_job
from .jobs_model import Job


def _print_job(job: Job) -> None:
    print()
    print(f"--- {job.title} ---")
    print(f"Platform: {job.platform} | Budget: {job.budget:.1f} {job.currency} | "
          f"Connects: {job.connects_required} | Proposals: {job.proposals}")
    print(f"Score: {job.score:.1f} | Fit: {job.fit_level} | Risk: {job.risk_level} | Action: {job.action}")
    print(f"URL: {job.url}")
    print("Reasons:")
    for r in job.reasons:
        print(f"  - {r}")


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description="Shortlist freelance jobs for your profile (v4 gold level).")
    parser.add_argument("--input", required=True, help="Path to jobs JSON file.")
    parser.add_argument("--output", required=True, help="Path to shortlist JSON file to write.")
    parser.add_argument("--top-n", type=int, default=5, help="How many jobs to keep (after filtering).")
    parser.add_argument("--profile", default="config/profile_v4.json", help="Profile JSON path.")
    parser.add_argument(
        "--include-watch",
        action="store_true",
        help="Include 'watchlist' jobs in the shortlist (not only 'apply_now').",
    )

    args = parser.parse_args(argv)

    try:
        jobs = load_jobs(args.input)
    except JobLoadError as e:
        print(f"ERROR loading jobs: {e}")
        return

    profile = load_profile(args.profile)

    evaluated: List[Job] = [score_job(j, profile) for j in jobs]

    if args.include_watch:
        filtered = [j for j in evaluated if j.action in ("apply_now", "watchlist")]
    else:
        filtered = [j for j in evaluated if j.action == "apply_now"]

    filtered.sort(key=lambda j: j.score, reverse=True)
    shortlisted = filtered[: args.top_n]

    print("========== SHORTLIST (v4) ==========")
    if not shortlisted:
        print("No jobs passed your filters based on profile + rules.")
    else:
        for j in shortlisted:
            _print_job(j)

    serialisable = [j.to_dict() for j in shortlisted]
    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(serialisable, f, indent=2)

    print(f"\nShortlist saved to: {args.output}")


if __name__ == "__main__":
    main()
