# Freelancing Automation – v5 (Profile + History-Aware Job Scorer)

This is **v5** of your freelancing job filter. It keeps the same clean core as v1/v2, but adds:
> **Note:** This v5 build extends v3/v4 by adding a configurable JSON **profile** plus a lightweight
> job **history tracker** so the scorer can tell fresh jobs from ones you've already inspected.


- JSON **profile config** (`config/profile_v5.json`) so you can tune scoring without editing code.
- Safer, clearer scoring with **explicit weights** and guard-rails.
- 7-layer verification notes for each core module.
- Full pytest test-suite that passes on Termux (Python 3.12).

## Layout

- `src/`
  - `jobs_model.py`       → dataclass for Job
  - `jobs_loader.py`      → load jobs from JSON
  - `jobs_scorer.py`      → profile-aware scoring logic
  - `jobs_shortlist_cli.py` → CLI wrapper
- `data/jobs_input_example.json` → example jobs you can tweak
- `config/profile_v3.json`       → your preferences (skills, min budget, etc.)
- `output/shortlist_v3.json`     → generated shortlist (created when you run the CLI)
- `tests/`                        → pytest tests
- `verification/`                 → 7-layer notes per module

## How to run on Termux

```bash
cd ~/AUTOMATION_FREELANCING/v3/freelancing_automation_v3

# (optional) run tests
PYTHONPATH=. pytest tests

# run the shortlist tool using example data + profile
python -m src.jobs_shortlist_cli   --input data/jobs_input_example.json   --output output/shortlist_v3.json   --top-n 5   --profile config/profile_v3.json
```

Then open `output/shortlist_v3.json` to see the filtered jobs.

You can:
- Edit `data/jobs_input_example.json` to paste real scraped jobs.
- Edit `config/profile_v3.json` to reflect your current focus.
