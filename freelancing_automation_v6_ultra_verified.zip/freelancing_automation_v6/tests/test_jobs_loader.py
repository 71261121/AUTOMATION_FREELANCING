from __future__ import annotations


import os
import sys

# Ensure 'src' package is importable when running pytest from project root
BASE_DIR = os.path.dirname(os.path.dirname(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)


import json
import os

import pytest

from src.jobs_loader import load_jobs, JobLoadError
from src.jobs_model import Job





def test_load_jobs_ok():
    path = os.path.join(BASE_DIR, "data", "jobs_input_example.json")
    jobs = load_jobs(path)
    assert isinstance(jobs, list)
    assert len(jobs) >= 3
    assert all(isinstance(j, Job) for j in jobs)


def test_load_jobs_missing_file():
    path = os.path.join(BASE_DIR, "data", "does_not_exist.json")
    with pytest.raises(JobLoadError):
        load_jobs(path)


def test_load_jobs_invalid_json(tmp_path):
    bad_file = tmp_path / "bad.json"
    bad_file.write_text("{not valid json}", encoding="utf-8")
    with pytest.raises(JobLoadError):
        load_jobs(str(bad_file))


def test_load_jobs_invalid_budget(tmp_path):
    data = [
        {
            "url": "x",
            "id": "1",
            "platform": "upwork",
            "title": "Bad budget",
            "description": "",
            "budget": "not-a-number",
            "currency": "USD",
            "is_hourly": False,
            "connects_required": 4,
            "proposals": 3,
            "has_attachments": False,
            "skills": [],
        }
    ]
    path = tmp_path / "jobs.json"
    path.write_text(json.dumps(data), encoding="utf-8")

    with pytest.raises(JobLoadError):
        load_jobs(str(path))