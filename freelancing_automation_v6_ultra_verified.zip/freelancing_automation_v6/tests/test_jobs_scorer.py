from __future__ import annotations


import os
import sys

# Ensure 'src' package is importable when running pytest from project root
BASE_DIR = os.path.dirname(os.path.dirname(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)


import os

from src.jobs_loader import load_jobs
from src.jobs_scorer import score_job





def _get_jobs():
    path = os.path.join(BASE_DIR, "data", "jobs_input_example.json")
    return load_jobs(path)


def _default_profile():
    from json import load
    profile_path = os.path.join(BASE_DIR, "config", "profile_v3.json")
    with open(profile_path, "r", encoding="utf-8") as f:
        return load(f)


def test_scoring_prefers_clean_design_jobs():
    jobs = _get_jobs()
    profile = _default_profile()

    scored = []
    for job in jobs:
        score, reasons = score_job(job, profile=profile)
        scored.append((score, job, reasons))

    scored.sort(key=lambda t: t[0], reverse=True)
    top_title = scored[0][1].title.lower()
    # Top job should be one of the design / PDF / deck style jobs, not the exam help
    assert "exam" not in top_title


def test_scoring_penalizes_red_flag_exam():
    jobs = _get_jobs()
    profile = _default_profile()

    exam_job = next(j for j in jobs if "exam" in j.title.lower())
    clean_job = next(j for j in jobs if "PDF" in j.title or "Slide deck" in j.title)

    exam_score, exam_reasons = score_job(exam_job, profile=profile)
    clean_score, clean_reasons = score_job(clean_job, profile=profile)

    assert exam_score < clean_score
    assert any("red-flag keyword" in r for r in exam_reasons)


def test_scoring_uses_min_budget_and_max_connects():
    jobs = _get_jobs()
    profile = _default_profile()

    low_budget = min(jobs, key=lambda j: j.budget)
    high_connects = max(jobs, key=lambda j: j.connects_required)

    low_score, low_reasons = score_job(low_budget, profile=profile)
    high_score, high_reasons = score_job(high_connects, profile=profile)

    # Just make sure the reasons mention budget/connects guard-rails
    assert any("minimum budget" in r for r in low_reasons)
    assert any("max connects" in r for r in high_reasons)