import os
from src.jobs_fetcher import fetch_jobs_from_source

def test_fetch_jobs_local_json():
    cfg = {
        "type": "local_json",
        "path": "data/jobs_input_example.json",
    }
    jobs = fetch_jobs_from_source(cfg)
    assert isinstance(jobs, list)
    assert len(jobs) > 0
    # each job should be a dict-like object with id + title
    first = jobs[0]
    assert "id" in first
    assert "title" in first
