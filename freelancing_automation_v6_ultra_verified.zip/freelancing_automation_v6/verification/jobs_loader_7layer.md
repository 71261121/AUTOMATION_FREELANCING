# jobs_loader.py — 7-layer verification (summary)

1. **File existence** – Raises `JobLoadError` with clear message when file is missing.
2. **JSON shape** – Enforces top-level list and per-item dict, otherwise raises `JobLoadError`.
3. **Type coercion** – Budget and integer fields validated via `_coerce_float` / `_coerce_int`.
4. **Defensive parsing** – Any unexpected shape triggers controlled `JobLoadError`, not a crash.
5. **Test coverage** – `tests/test_jobs_loader.py` covers happy path + invalid JSON + bad budget.
6. **Android/Termux safety** – Uses only standard `open` + `json` (no platform-specific calls).
7. **Future-proofing** – Extra keys in JSON are safely ignored; missing keys get safe defaults.
