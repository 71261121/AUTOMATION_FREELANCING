# jobs_model.py — 7-layer verification (summary)

1. **Scope check** – Only holds stable job fields (no profile-specific or transient fields).
2. **Type check** – Each attribute has a clear type (str, float, int, bool, list[str]).
3. **Construction check** – Used only via `jobs_loader.load_jobs` so all data is validated there.
4. **Serialization check** – `to_dict()` returns only JSON-serialisable primitives.
5. **Forward-compatibility** – New fields can be added later without breaking v3.
6. **Android/Termux safety** – No imports outside stdlib, no file I/O here.
7. **Test coverage** – Indirectly covered by loader + scorer tests that rely on Job objects.
