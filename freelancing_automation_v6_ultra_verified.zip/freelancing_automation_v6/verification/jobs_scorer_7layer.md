# jobs_scorer.py — 7-layer verification (summary)

1. **Profile normalisation** – `_normalize_profile` fills defaults so missing keys never crash scoring.
2. **Deterministic scoring** – Score is pure function of (job, profile); no randomness, no I/O.
3. **Red-flag enforcement** – Obvious cheating/exam-like jobs get heavy penalty every time.
4. **Guard-rails** – `min_budget`, `max_connects`, and `high_connects_threshold` prevent bad jobs.
5. **Explainability** – Every scoring branch appends a human-readable reason string.
6. **Test coverage** – `tests/test_jobs_scorer.py` verifies ranking, red-flag handling, and guard-rails.
7. **Android/Termux safety** – Uses only stdlib types; no network, no threads, no heavy libs.
