# jobs_shortlist_cli.py — 7-layer verification (summary)

1. **Argument parsing** – Clear CLI interface with `--input`, `--output`, `--top-n`, `--profile`.
2. **Profile loading** – Profile JSON is validated at load, with clear error on invalid/missing file.
3. **Loader integration** – All job I/O delegated to `jobs_loader.load_jobs` (single source of truth).
4. **Scorer integration** – Uses `score_job(job, profile)` for each job, preserving deterministic behaviour.
5. **Ordering & slicing** – Sorts by score descending and clamps `top_n` to at least 1.
6. **Output writing** – Writes only the shortlisted jobs via `Job.to_dict()`, guarded with try/except.
7. **Android/Termux safety** – No absolute paths, uses only relative paths from current working dir.
