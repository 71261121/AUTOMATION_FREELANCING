from __future__ import annotations

from dataclasses import dataclass
from typing import List, Dict, Any, Optional


@dataclass
class Job:
    """Single freelancing job posting.

    This is intentionally small and stable so later versions (v4+)
    can reuse it without breaking v3.
    """

    url: str
    id: str
    platform: str  # e.g., "upwork", "guru"
    title: str
    description: str
    budget: float
    currency: str
    is_hourly: bool
    connects_required: int
    proposals: int
    has_attachments: bool
    skills: List[str]
    seen_before: bool = False
    times_seen: int = 0
    last_seen: Optional[str] = None
    history_flag: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "url": self.url,
            "id": self.id,
            "platform": self.platform,
            "title": self.title,
            "description": self.description,
            "budget": self.budget,
            "currency": self.currency,
            "is_hourly": self.is_hourly,
            "connects_required": self.connects_required,
            "proposals": self.proposals,
            "has_attachments": self.has_attachments,
            "skills": list(self.skills),
            "seen_before": self.seen_before,
            "times_seen": self.times_seen,
            "last_seen": self.last_seen,
            "history_flag": self.history_flag,
        }
