# Mark src as a package so 'python -m src.jobs_shortlist_cli' works.

