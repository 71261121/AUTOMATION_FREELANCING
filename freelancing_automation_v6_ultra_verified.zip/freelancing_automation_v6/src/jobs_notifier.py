"""
jobs_notifier.py (v6 ultra)

Small, defensive wrapper around Telegram Bot API.

Design goals:
- If Telegram is not configured, do nothing (but print a clear message).
- If network / requests is missing, do **not** crash the main script.
- Keep output text short and readable on a small mobile screen.
"""

from __future__ import annotations

from typing import Any, Dict, Iterable, List


def _format_job_line(job: Dict[str, Any]) -> str:
    """
    Turn a single shortlisted job dict into a one-line summary for Telegram.
    """
    title = str(job.get("title", "")).strip() or "Untitled job"
    platform = job.get("platform", "unknown")
    budget = job.get("budget")
    currency = job.get("currency", "")
    score = job.get("score")
    url = job.get("url", "")

    budget_part = ""
    if budget is not None:
        budget_part = f"{budget} {currency}".strip()

    score_part = f" | score {score}" if score is not None else ""
    pieces = [f"• {title}", f"[{platform}]"]
    if budget_part:
        pieces.append(budget_part)
    line = " ".join(pieces) + score_part
    if url:
        line += f"\n{url}"
    return line


def build_telegram_message(shortlist: List[Dict[str, Any]], profile_name: str | None = None) -> str:
    """
    Build the multi-line text message for Telegram from the shortlist.
    """
    header = "📌 Freelancing shortlist"
    if profile_name:
        header += f" — {profile_name}"

    if not shortlist:
        return header + "\n(no jobs matched filters)"

    lines: List[str] = [header, ""]
    for job in shortlist:
        lines.append(_format_job_line(job))
        lines.append("")  # blank between jobs

    return "\n".join(lines).rstrip()


def send_telegram_shortlist(
    shortlist: List[Dict[str, Any]],
    telegram_cfg: Dict[str, Any],
    profile_name: str | None = None,
) -> None:
    """
    Send the shortlist to Telegram, if enabled in config.

    Expected config shape:

      "telegram": {
        "enabled": false,
        "bot_token": "123:abc",
        "chat_id": "123456789",
        "max_jobs": 5,
        "dry_run": true
      }

    Behaviour:
      - If enabled is False or missing -> do nothing.
      - If bot_token/chat_id missing -> print clear warning, but don't crash.
      - If dry_run is True        -> just print the message to stdout.
      - Network / requests errors -> print a warning, don't raise.
    """
    enabled = bool(telegram_cfg.get("enabled", False))
    if not enabled:
        # Silent no-op is fine; user may not want Telegram at all.
        print("[v6] Telegram disabled in config; skipping notification.")
        return

    # Basic validation
    bot_token = telegram_cfg.get("bot_token")
    chat_id = telegram_cfg.get("chat_id")
    if not bot_token or not chat_id:
        print("[v6] Telegram config missing bot_token or chat_id; skipping notification.")
        return

    max_jobs = int(telegram_cfg.get("max_jobs", 5))
    dry_run = bool(telegram_cfg.get("dry_run", True))

    # Trim shortlist for message size
    trimmed = shortlist[:max_jobs]
    text = build_telegram_message(trimmed, profile_name=profile_name)

    if dry_run:
        print("[v6] Telegram dry-run ON. Message would be:")
        print("----------------------------------------")
        print(text)
        print("----------------------------------------")
        return

    # Real send using Telegram Bot API
    try:
        import requests  # type: ignore
    except Exception as exc:  # pragma: no cover - only hit if requests missing
        print("[v6] Cannot send Telegram message: 'requests' package not available.")
        print("      Install it with: pip install requests")
        return

    api_url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
    payload = {
        "chat_id": chat_id,
        "text": text,
        "parse_mode": "Markdown",
        "disable_web_page_preview": False,
    }

    try:
        resp = requests.post(api_url, json=payload, timeout=15)
        if resp.ok:
            print("[v6] Telegram notification sent successfully.")
        else:  # pragma: no cover - depends on network
            print(f"[v6] Telegram API returned HTTP {resp.status_code}: {resp.text}")
    except Exception as exc:  # pragma: no cover - depends on network
        print(f"[v6] Error sending Telegram message: {exc}")
