"""
run_v6_pipeline.py

End‑to‑end orchestration for **Version 6** of the freelancing automation project.

High‑level steps:

  1. Read JSON config (which profile, which source, which output path, etc.)
  2. Fetch raw jobs from the configured source (local JSON for now).
  3. Convert to Job objects and apply history weighting.
  4. Score + filter them using v5 scoring logic.
  5. Save a machine‑readable shortlist JSON.
  6. Optionally send a compact summary to Telegram.

This script is designed to be:

  - 100% compatible with Termux / Android
  - Defensive: clear error messages instead of cryptic tracebacks
  - Backwards‑compatible with your working v5 core logic
"""

from __future__ import annotations

from typing import Any, Dict, List
import argparse
import json
from datetime import datetime, timezone
from pathlib import Path

from .jobs_model import Job
from .jobs_scorer import score_job, build_profile
from .jobs_loader import (
    load_jobs,
    load_history,
    save_history,
    apply_history_to_jobs,
)
from .jobs_fetcher import fetch_jobs_from_source
from .jobs_notifier import send_telegram_shortlist


def _project_root() -> Path:
    return Path(__file__).resolve().parents[1]


def _load_config(config_path: str) -> Dict[str, Any]:
    root = _project_root()
    cfg_path = (root / config_path).resolve()
    if not cfg_path.exists():
        raise FileNotFoundError(f"Config file not found: {cfg_path}")
    with cfg_path.open("r", encoding="utf-8") as f:
        return json.load(f)


def _resolve_path(rel_path: str) -> Path:
    """
    Helper to make paths in config relative to project root.
    """
    root = _project_root()
    return (root / rel_path).resolve()


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def run_pipeline(config_path: str) -> None:
    """
    Main v6 pipeline.

    This function is imported by tests (indirectly) and called by the CLI
    at the bottom of this file.
    """
    cfg = _load_config(config_path)

    source_cfg: Dict[str, Any] = cfg.get("source", {})
    output_cfg: Dict[str, Any] = cfg.get("output", {})
    history_cfg: Dict[str, Any] = cfg.get("history", {})
    profile_cfg: Dict[str, Any] = cfg.get("profile", {})
    telegram_cfg: Dict[str, Any] = cfg.get("telegram", {})

    profile_name = profile_cfg.get("name", "default")

    # Resolve paths from config
    history_path = _resolve_path(history_cfg.get("path", "data/jobs_seen_history.json"))
    output_path = _resolve_path(output_cfg.get("path", "output/shortlist_v6.json"))

    print(f"[v6] Using config : {config_path}")
    print(f"[v6] History file: {history_path}")
    print(f"[v6] Output file : {output_path}")

    # ------------------------------------------------------------------
    # 1) Load jobs from source
    # ------------------------------------------------------------------
    source_type = source_cfg.get("type", "local_json")

    if source_type == "local_json":
        # Re‑use the proven v5 loader for local JSON.
        jobs_path = source_cfg.get("path", "data/jobs_input_example.json")
        jobs_path_resolved = _resolve_path(jobs_path)
        jobs: List[Job] = load_jobs(str(jobs_path_resolved))
    else:
        # For http_json or future sources we go through jobs_fetcher and
        # then convert dicts -> Job objects using the same fields.
        raw_jobs = fetch_jobs_from_source(source_cfg)
        jobs = []
        for raw in raw_jobs:
            jobs.append(
                Job(
                    id=str(raw.get("id")),
                    platform=str(raw.get("platform", "")),
                    title=str(raw.get("title", "")),
                    description=str(raw.get("description", "")),
                    budget=raw.get("budget"),
                    currency=str(raw.get("currency", "")),
                    is_hourly=bool(raw.get("is_hourly", False)),
                    connects_required=raw.get("connects_required"),
                    proposals=raw.get("proposals"),
                    has_attachments=bool(raw.get("has_attachments", False)),
                    skills=list(raw.get("skills", [])),
                    url=str(raw.get("url", "")),
                    seen_before=False,
                    times_seen=0,
                    last_seen=None,
                    history_flag=None,
                )
            )

    if not jobs:
        print("[v6] No jobs loaded from source; nothing to do.")
        return

    print(f"[v6] Loaded {len(jobs)} jobs from source type={source_type}")

    # ------------------------------------------------------------------
    # 2) Load and apply history
    # ------------------------------------------------------------------
    history: Dict[str, Any] = {}
    if history_cfg.get("enabled", True):
        history = load_history(str(history_path))
        # apply_history_to_jobs mutates the list in-place and returns None
        apply_history_to_jobs(jobs, history)

    # ------------------------------------------------------------------
    # 3) Build scoring profile
    # ------------------------------------------------------------------
    profile = build_profile(profile_cfg)

    # ------------------------------------------------------------------
    # 4) Score + filter jobs
    # ------------------------------------------------------------------
    top_n = int(output_cfg.get("top_n", 5))
    connect_limit = output_cfg.get("connect_limit")  # can be None
    budget_floor = output_cfg.get("budget_floor")    # can be None

    scored: List[Dict[str, Any]] = []
    for job in jobs:
        score, reasons = score_job(job, profile)

        if connect_limit is not None and job.connects_required is not None:
            if job.connects_required > int(connect_limit):
                continue

        if budget_floor is not None and job.budget is not None:
            if job.budget < float(budget_floor):
                continue

        jd = job.to_dict()
        jd["score"] = score
        jd["reasons"] = reasons
        scored.append(jd)

    if not scored:
        print("[v6] No jobs passed filters; skipping file/update.")
        return

    scored.sort(key=lambda j: j.get("score", 0), reverse=True)
    shortlist = scored[:top_n]

    # ------------------------------------------------------------------
    # 5) Update and save history (simple in‑place update)
    # ------------------------------------------------------------------
    if history_cfg.get("enabled", True):
        jobs_map = history.get("jobs", {})
        now_iso = _utc_now_iso()
        run_id = history_cfg.get("run_id_prefix", "run-") + now_iso.replace(":", "").replace("-", "")

        for job in shortlist:
            jid = str(job.get("id"))
            info = jobs_map.get(jid, {"flag": None, "times_seen": 0, "last_seen": None})
            info["times_seen"] = int(info.get("times_seen", 0)) + 1
            info["last_seen"] = now_iso
            jobs_map[jid] = info

        history["jobs"] = jobs_map
        history["meta"] = {
            "last_run_id": run_id,
            "last_updated": now_iso,
            "version": 1,
        }

        history_path.parent.mkdir(parents=True, exist_ok=True)
        save_history(str(history_path), history)

    # ------------------------------------------------------------------
    # 6) Write shortlist JSON
    # ------------------------------------------------------------------
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", encoding="utf-8") as f:
        json.dump(shortlist, f, indent=2, ensure_ascii=False)
    print(f"[v6] Shortlist saved to: {output_path}")

    # ------------------------------------------------------------------
    # 7) Optional Telegram notification
    # ------------------------------------------------------------------
    try:
        send_telegram_shortlist(shortlist, telegram_cfg, profile_name=profile_name)
    except Exception as exc:
        print(f"[v6] Warning: Telegram notification failed: {exc}")


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description="Run v6 freelancing automation pipeline")
    parser.add_argument(
        "--config",
        default="config/profile_v6.json",
        help="Path to JSON config file (relative to project root).",
    )
    args = parser.parse_args(argv)
    run_pipeline(args.config)


if __name__ == "__main__":  # pragma: no cover
    main()
