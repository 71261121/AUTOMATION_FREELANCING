from __future__ import annotations

import argparse
import json
from typing import Any, Dict, List, Optional

from .jobs_loader import (
    load_jobs,
    JobLoadError,
    load_history,
    apply_history_to_jobs,
    update_history_with_jobs,
    save_history,
)
from .jobs_model import Job
from .jobs_scorer import score_job, build_profile


def _load_profile(path: Optional[str]) -> Dict[str, Any]:
    """Load a JSON profile from disk, or return an empty dict."""
    if not path:
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        # Fall back to empty, caller will layer defaults on top.
        return {}
    except json.JSONDecodeError as exc:
        raise SystemExit(f"Profile JSON is invalid: {exc}") from exc


def shortlist_jobs(
    input_path: str,
    output_path: str,
    top_n: int,
    profile_path: Optional[str] = None,
    history_path: Optional[str] = None,
    run_id: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """Core orchestration function used by the CLI and easily testable."""
    # 1) Load raw jobs from JSON
    jobs = load_jobs(input_path)

    # 2) Load profile and build a fully-populated profile dict
    raw_profile = _load_profile(profile_path)
    profile = build_profile(raw_profile)

    # 3) Load history (if requested) and apply annotations
    history = None
    if history_path:
        history = load_history(history_path)
        apply_history_to_jobs(jobs, history)

    # 4) Score each job
    scored: List[Dict[str, Any]] = []
    for job in jobs:
        score, reasons = score_job(job, profile)
        scored.append(
            {
                "url": job.url,
                "id": job.id,
                "platform": job.platform,
                "title": job.title,
                "description": job.description,
                "budget": job.budget,
                "currency": job.currency,
                "is_hourly": job.is_hourly,
                "connects_required": job.connects_required,
                "proposals": job.proposals,
                "has_attachments": job.has_attachments,
                "skills": list(job.skills),
                "score": score,
                "reasons": reasons,
                "seen_before": getattr(job, "seen_before", False),
                "times_seen": getattr(job, "times_seen", 0),
                "last_seen": getattr(job, "last_seen", None),
                "history_flag": getattr(job, "history_flag", None),
            }
        )

    # 5) Sort and slice
    scored.sort(key=lambda j: j["score"], reverse=True)
    shortlisted = scored[:top_n]

    # 6) Persist shortlist JSON
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(shortlisted, f, indent=2)

    # 7) Update and persist history (if used)
    if history_path:
        if history is None:
            history = {}
        if run_id is None:
            # cheap unique-ish run id
            import time as _time

            run_id = f"run-{int(_time.time())}"
        updated = update_history_with_jobs(jobs, history, run_id)
        save_history(history_path, updated)

    return shortlisted


def main(argv: Optional[List[str]] = None) -> None:
    parser = argparse.ArgumentParser(
        description="Score and shortlist freelance jobs based on your preferences.",
    )
    parser.add_argument(
        "--input",
        required=True,
        help="Path to input JSON file containing a list of jobs.",
    )
    parser.add_argument(
        "--output",
        required=True,
        help="Path where the shortlisted jobs JSON will be written.",
    )
    parser.add_argument(
        "--top-n",
        type=int,
        default=5,
        help="How many top jobs to keep in the shortlist (default: 5).",
    )
    parser.add_argument(
        "--profile",
        default="config/profile_v5.json",
        help="Path to the scoring profile JSON (default: config/profile_v5.json).",
    )
    parser.add_argument(
        "--history",
        default="data/jobs_seen_history.json",
        help=(
            "Optional path to a JSON file where job history will be stored. "
            "If the file is missing, it will be created automatically."
        ),
    )
    parser.add_argument(
        "--run-id",
        default=None,
        help="Optional run identifier that will be written into the history file.",
    )

    args = parser.parse_args(argv)

    try:
        shortlist_jobs(
            input_path=args.input,
            output_path=args.output,
            top_n=args.top_n,
            profile_path=args.profile,
            history_path=args.history,
            run_id=args.run_id,
        )
    except JobLoadError as exc:
        raise SystemExit(f"Error loading jobs: {exc}") from exc


if __name__ == "__main__":
    main()
