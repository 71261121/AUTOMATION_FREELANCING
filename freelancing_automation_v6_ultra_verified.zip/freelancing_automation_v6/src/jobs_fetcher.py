"""
jobs_fetcher.py (v6 ultra)

Responsible for getting raw job data from different "sources" defined
in the JSON config, and normalising it into a simple list[dict].

This module is intentionally very small and defensive so that:

- Pytest tests stay simple and fast.
- Termux / Android environments don't break if `requests` is missing.
- The rest of the pipeline can treat the result as plain Python dicts.
"""

from __future__ import annotations

from typing import Any, Dict, List
import json
import pathlib


def _project_root() -> pathlib.Path:
    """
    Return the project root directory (the folder that contains src/, data/, config/).

    We compute this relative to this file so it works no matter where the
    user runs Python from (Termux, laptop, etc.).
    """
    return pathlib.Path(__file__).resolve().parents[1]


def _load_local_json(path: str) -> List[Dict[str, Any]]:
    """
    Load a jobs JSON file from the repository and return a list of dicts.

    If the JSON is:
      - a list -> we return it directly (after basic validation)
      - a dict with key "jobs" -> we return value of that key
    """
    root = _project_root()
    json_path = (root / path).resolve()

    if not json_path.exists():
        raise FileNotFoundError(f"Jobs JSON not found at: {json_path}")

    with json_path.open("r", encoding="utf-8") as f:
        data = json.load(f)

    if isinstance(data, dict):
        # common pattern: {"jobs": [...]}
        jobs = data.get("jobs", [])
    else:
        jobs = data

    if not isinstance(jobs, list):
        raise ValueError("Expected JSON to contain a list of jobs.")

    normalised: List[Dict[str, Any]] = []
    for idx, item in enumerate(jobs):
        if not isinstance(item, dict):
            raise ValueError(f"Job at index {idx} is not an object/dict.")
        normalised.append(item)
    return normalised


def _load_http_json(cfg: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Optional HTTP JSON source.

    This is **not** used by the tests and is kept very defensive:
    if `requests` is missing, we raise a clear error telling the user
    how to install it.

    Expected config shape:
      {
        "type": "http_json",
        "url": "...",
        "params": {...},         # optional
        "timeout": 15.0          # optional
      }
    """
    try:
        import requests  # type: ignore
    except Exception as exc:  # pragma: no cover - only hit on misconfigured systems
        raise RuntimeError(
            "http_json source requires the 'requests' package. "
            "Install it with: pip install requests"
        ) from exc

    url = cfg.get("url")
    if not url:
        raise ValueError("http_json source requires a 'url' key.")

    params = cfg.get("params") or None
    timeout = float(cfg.get("timeout", 15.0))

    resp = requests.get(url, params=params, timeout=timeout)
    resp.raise_for_status()
    data = resp.json()

    if isinstance(data, dict):
        # try a couple of common keys
        jobs = data.get("jobs") or data.get("data") or []
    else:
        jobs = data

    if not isinstance(jobs, list):
        raise ValueError("Expected HTTP JSON response to be a list of jobs.")

    normalised: List[Dict[str, Any]] = []
    for idx, item in enumerate(jobs):
        if not isinstance(item, dict):
            raise ValueError(f"Job at index {idx} from HTTP source is not an object/dict.")
        normalised.append(item)
    return normalised


def fetch_jobs_from_source(cfg: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Public entry point used by:
      - tests/test_jobs_fetcher.py
      - v6 pipeline (if you want to in the future)

    It always returns a **list of plain dicts**, which keeps it easy to test.

    For Termux / offline usage, the default `local_json` source is enough.
    """
    source_type = cfg.get("type", "local_json")

    if source_type == "local_json":
        path = cfg.get("path")
        if not path:
            raise ValueError("local_json source requires a 'path' key.")
        return _load_local_json(path)

    if source_type == "http_json":
        return _load_http_json(cfg)

    raise ValueError(f"Unknown jobs source type: {source_type!r}")
