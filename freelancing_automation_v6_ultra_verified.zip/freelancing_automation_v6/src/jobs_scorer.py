from __future__ import annotations

from typing import Dict, Any, List, Tuple

from .jobs_model import Job


def _normalize_profile(raw_profile: Dict[str, Any]) -> Dict[str, Any]:
    """Fill in defaults so scoring never crashes if a key is missing.

    This keeps v3 robust even when you only partially edit profile_v3.json.
    """
    profile = dict(raw_profile or {})

    profile.setdefault("min_budget", 30.0)
    profile.setdefault("max_connects", 16)
    profile.setdefault("healthy_proposals_min", 5)
    profile.setdefault("healthy_proposals_max", 20)
    profile.setdefault("high_connects_threshold", 16)

    profile.setdefault("core_skills", [])
    profile.setdefault("bonus_keywords", [])
    profile.setdefault("red_flags", ["exam", "test", "homework"])
    profile.setdefault("preferred_platforms", ["upwork", "guru"])

    weights = profile.setdefault("weights", {})
    weights.setdefault("attachments", 25.0)
    weights.setdefault("fixed_price", 15.0)
    weights.setdefault("hourly_base", 0.0)
    weights.setdefault("budget_factor", 0.2)      # 0.2 * 60 = 12 points for $60
    weights.setdefault("budget_cap", 20.0)
    weights.setdefault("healthy_competition", 15.0)
    weights.setdefault("high_connects_penalty", -5.0)
    weights.setdefault("core_skill_per_hit", 3.0)
    weights.setdefault("bonus_keyword", 2.0)
    weights.setdefault("red_flag_penalty", -30.0)
    weights.setdefault("below_min_budget_penalty", -10.0)
    weights.setdefault("above_max_connects_penalty", -8.0)
    weights.setdefault("preferred_platform_bonus", 4.0)
    weights.setdefault("fresh_job_bonus", 0.0)
    weights.setdefault("seen_job_penalty", 0.0)
    weights.setdefault("history_soft_blacklist_penalty", -15.0)

    profile["weights"] = weights
    return profile


def score_job(job: Job, profile: Dict[str, Any] | None = None) -> Tuple[float, List[str]]:
    """Score a job using the given profile.

    Returns (score, reasons).
    """
    profile = _normalize_profile(profile or {})
    weights = profile["weights"]

    score = 0.0
    reasons: List[str] = []

    # Pre-build searchable text (lowercase)
    text_blob = " ".join(
        [
            job.title,
            job.description,
            " ".join(job.skills),
        ]
    ).lower()

    # 1) Attachments
    if job.has_attachments:
        score += weights["attachments"]
        reasons.append("+25: has attachment(s)")

    # 2) Fixed vs hourly
    if not job.is_hourly:
        score += weights["fixed_price"]
        reasons.append("+15: fixed-price job")
    else:
        base = weights.get("hourly_base", 0.0)
        if base:
            score += base
            reasons.append(f"+{base}: hourly job base score")

    # 3) Budget contribution (with cap)
    budget_factor = weights["budget_factor"]
    budget_cap = weights["budget_cap"]
    budget_score = min(job.budget * budget_factor, budget_cap)
    score += budget_score
    reasons.append(f"+{budget_score:.1f}: budget-based score (budget={job.budget})")

    # 4) Proposals window
    healthy_min = int(profile["healthy_proposals_min"])
    healthy_max = int(profile["healthy_proposals_max"])
    if healthy_min <= job.proposals <= healthy_max:
        score += weights["healthy_competition"]
        reasons.append("+15: healthy competition (" f"{healthy_min}-{healthy_max} proposals)")

    # 5) Connects penalty (high)
    if job.connects_required >= int(profile["high_connects_threshold"]):
        score += weights["high_connects_penalty"]
        reasons.append("-5: high connects required (>=" f"{profile['high_connects_threshold']})")

    # 6) Core skills
    core_hits = 0
    for kw in profile["core_skills"]:
        kw_l = kw.lower().strip()
        if kw_l and kw_l in text_blob:
            core_hits += 1
    if core_hits:
        inc = core_hits * weights["core_skill_per_hit"]
        score += inc
        reasons.append(f"+{int(inc)}: matches your core skills ({core_hits} hits)")

    # 7) Bonus keywords
    bonus_hits = 0
    for kw in profile["bonus_keywords"]:
        kw_l = kw.lower().strip()
        if kw_l and kw_l in text_blob:
            bonus_hits += 1
    if bonus_hits:
        inc = bonus_hits * weights["bonus_keyword"]
        score += inc
        reasons.append(f"+{int(inc)}: bonus keyword matches ({bonus_hits} hits)")

    # 8) Red flags (first red flag is enough)
    for kw in profile["red_flags"]:
        kw_l = kw.lower().strip()
        if kw_l and kw_l in text_blob:
            score += weights["red_flag_penalty"]
            reasons.append(f"-30: red-flag keyword: '{kw_l}'")
            break

    # 9) Below min budget
    if job.budget < float(profile["min_budget"]):
        score += weights["below_min_budget_penalty"]
        reasons.append(
            f"{int(weights['below_min_budget_penalty'])}: below your minimum budget ({profile['min_budget']})"
        )

    # 10) Above max connects
    if job.connects_required > int(profile["max_connects"]):
        score += weights["above_max_connects_penalty"]
        reasons.append(
            f"{int(weights['above_max_connects_penalty'])}: above your max connects ({profile['max_connects']})"
        )

    # 11) Preferred platforms bonus
    if job.platform.lower() in [p.lower() for p in profile["preferred_platforms"]]:
        score += weights["preferred_platform_bonus"]
        reasons.append("+4: preferred platform")

    return score, reasons

def build_profile(raw_profile: Dict[str, Any]) -> Dict[str, Any]:
    """Public wrapper kept for clarity / future extension.

    Internally delegates to ``_normalize_profile`` so older tests and
    callers remain valid while newer code can use the clearer name.
    """
    return _normalize_profile(raw_profile)
