from __future__ import annotations

import json
import os
import datetime as _dt
from copy import deepcopy
from typing import List

from .jobs_model import Job


class JobLoadError(Exception):
    """Raised when the JSON input is invalid or cannot be parsed into jobs."""


def _coerce_float(value, field_name: str) -> float:
    try:
        return float(value)
    except (TypeError, ValueError) as exc:
        raise JobLoadError(f"Invalid numeric value for '{field_name}': {value!r}") from exc


def _coerce_int(value, field_name: str) -> int:
    try:
        return int(value)
    except (TypeError, ValueError) as exc:
        raise JobLoadError(f"Invalid integer value for '{field_name}': {value!r}") from exc


def load_jobs(path: str) -> List[Job]:
    """Load jobs from a JSON file.

    Expected structure:
      [
        {
          "url": "...",
          "id": "...",
          "platform": "upwork" | "guru" | "...",
          "title": "...",
          "description": "...",
          "budget": 50.0,
          "currency": "USD",
          "is_hourly": false,
          "connects_required": 8,
          "proposals": 12,
          "has_attachments": true,
          "skills": ["PowerPoint", "Pitch Deck"]
        },
        ...
      ]
    """
    try:
        with open(path, "r", encoding="utf-8") as f:
            raw = json.load(f)
    except FileNotFoundError as exc:
        raise JobLoadError(f"Input file not found: {path}") from exc
    except json.JSONDecodeError as exc:
        raise JobLoadError(f"Invalid JSON in input file: {path}") from exc

    if not isinstance(raw, list):
        raise JobLoadError("Top-level JSON must be a list of jobs")

    jobs: List[Job] = []
    for idx, item in enumerate(raw):
        if not isinstance(item, dict):
            raise JobLoadError(f"Job at index {idx} is not an object")

        try:
            job = Job(
                url=str(item.get("url", "")),
                id=str(item.get("id", f"job-{idx}")),
                platform=str(item.get("platform", "unknown")),
                title=str(item.get("title", "")),
                description=str(item.get("description", "")),
                budget=_coerce_float(item.get("budget", 0.0), "budget"),
                currency=str(item.get("currency", "USD")),
                is_hourly=bool(item.get("is_hourly", False)),
                connects_required=_coerce_int(item.get("connects_required", 0), "connects_required"),
                proposals=_coerce_int(item.get("proposals", 0), "proposals"),
                has_attachments=bool(item.get("has_attachments", False)),
                skills=[str(s) for s in (item.get("skills") or [])],
            )
        except JobLoadError:
            raise
        except Exception as exc:  # defensive: don't let a surprise shape crash the run
            raise JobLoadError(f"Failed to parse job at index {idx}: {exc}") from exc

        jobs.append(job)

    return jobs

HISTORY_TEMPLATE: Dict[str, Any] = {
    "meta": {
        "version": 1,
        "last_run_id": None,
        "last_updated": None,
    },
    "jobs": {},
}


def _now_iso() -> str:
    """Return current UTC time as a compact ISO string with Z suffix."""
    return _dt.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"


def load_history(path: str) -> Dict[str, Any]:
    """Load history JSON from disk, or return a fresh template.

    The structure is:

    {

      "meta": {"version": 1, "last_run_id": ..., "last_updated": ...},

      "jobs": {

         "job-id": {"times_seen": int, "last_seen": str, "flag": Optional[str]}

      }

    }

    """
    if not path:
        return deepcopy(HISTORY_TEMPLATE)

    if not os.path.exists(path):
        return deepcopy(HISTORY_TEMPLATE)

    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            return deepcopy(HISTORY_TEMPLATE)
        # ensure keys exist
        data.setdefault("meta", {})
        data.setdefault("jobs", {})
        return data
    except Exception:
        # On any error, fall back to a fresh history object
        return deepcopy(HISTORY_TEMPLATE)


def apply_history_to_jobs(jobs: List[Job], history: Dict[str, Any]) -> None:
    """Annotate Job instances with history information in-place."""
    jobs_section = history.get("jobs", {}) or {}
    for job in jobs:
        info = jobs_section.get(job.id)
        if info:
            job.seen_before = True
            job.times_seen = int(info.get("times_seen", 0) or 0)
            job.last_seen = info.get("last_seen")
            job.history_flag = info.get("flag")
        else:
            job.seen_before = False
            job.times_seen = 0
            job.last_seen = None
            job.history_flag = None


def update_history_with_jobs(
    jobs: List[Job],
    history: Dict[str, Any],
    run_id: str,
) -> Dict[str, Any]:
    """Return an updated history object after scoring this batch of jobs."""
    jobs_section = history.setdefault("jobs", {})
    now = _now_iso()

    for job in jobs:
        entry = jobs_section.setdefault(
            job.id,
            {"times_seen": 0, "last_seen": None, "flag": None},
        )
        entry["times_seen"] = int(entry.get("times_seen", 0) or 0) + 1
        entry["last_seen"] = now

        # Light-touch heuristic example: if a job has zero/negative budget
        # or clearly looks like a test posting, mark it as low-priority.
        title = (job.title or "").lower()
        if (job.budget or 0) <= 0 or title.startswith("test "):
            existing_flag = entry.get("flag")
            if not existing_flag:
                entry["flag"] = "skip_low_quality"

    meta = history.setdefault("meta", {})
    meta["version"] = HISTORY_TEMPLATE["meta"]["version"]
    meta["last_run_id"] = run_id
    meta["last_updated"] = now
    return history


def save_history(path: str, history: Dict[str, Any]) -> None:
    """Persist history to disk in a robust way."""
    if not path:
        return
    directory = os.path.dirname(path)
    if directory:
        os.makedirs(directory, exist_ok=True)
    tmp_path = path + ".tmp"
    with open(tmp_path, "w", encoding="utf-8") as f:
        json.dump(history, f, indent=2, sort_keys=True)
    os.replace(tmp_path, path)
