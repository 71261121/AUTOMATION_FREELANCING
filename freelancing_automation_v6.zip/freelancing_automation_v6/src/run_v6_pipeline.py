"""
run_v6_pipeline.py
------------------

Single-entry script for the v6 pipeline:

1) Load v6 config (profile + source + history + output + telegram)
2) Fetch jobs from the configured source
3) Apply "seen before" history
4) Score + sort jobs using the existing scoring engine
5) Persist updated history
6) Save shortlist JSON
7) Optionally send Telegram notification

Usage (from project root):

  cd v6/freelancing_automation_v6
  python -m src.run_v6_pipeline --config config/profile_v6.json

You can duplicate profile_v6.json to create different profiles/sources.
"""

from __future__ import annotations

from typing import Any, Dict, List
import argparse
import json
import time
import pathlib

from .jobs_model import Job
from .jobs_loader import (
    load_history,
    save_history,
    apply_history_to_jobs,
    update_history_with_jobs,
)
from .jobs_scorer import build_profile, score_job
from .jobs_fetcher import fetch_jobs_from_source
from .jobs_notifier import send_telegram_shortlist


def _load_config(path: str) -> Dict[str, Any]:
    p = pathlib.Path(path).expanduser()
    with p.open("r", encoding="utf-8") as f:
        return json.load(f)


def _ensure_parent(path: str) -> None:
    pathlib.Path(path).expanduser().parent.mkdir(parents=True, exist_ok=True)


def run_pipeline(config_path: str) -> Dict[str, Any]:
    cfg = _load_config(config_path)

    profile_cfg = cfg.get("profile") or {}
    source_cfg = cfg.get("source") or {}
    history_cfg = cfg.get("history") or {}
    output_cfg = cfg.get("output") or {}
    telegram_cfg = cfg.get("telegram") or {}

    history_path = history_cfg.get("path") or "data/jobs_seen_history.json"
    output_path = output_cfg.get("path") or "output/shortlist_v6.json"
    top_n = int(output_cfg.get("top_n") or 5)

    print(f"[v6] Using config: {config_path}")
    print(f"[v6] History file: {history_path}")
    print(f"[v6] Output file : {output_path}")

    # 1) Fetch + parse jobs
    jobs: List[Dict[str, Any]] = fetch_jobs_from_source(source_cfg)
    print(f"[v6] Loaded {len(jobs)} jobs from source type={source_cfg.get('type', 'local_json')}")

    # 2) History: mark seen / flagged
    history = load_history(history_path)
    apply_history_to_jobs(jobs, history)

    # 3) Build profile + score
    profile = build_profile(profile_cfg)
    run_id = f"run-{int(time.time())}"

    scored: List[Dict[str, Any]] = []
    for job in jobs:
        scored_job = score_job(job, profile)
        scored.append(scored_job)

    scored.sort(key=lambda j: j.get("score", 0), reverse=True)
    shortlist = scored[:top_n]

    # 4) Update + save history
    update_history_with_jobs(shortlist, history, run_id=run_id)
    _ensure_parent(history_path)
    save_history(history_path, history)

    # 5) Save shortlist JSON
    _ensure_parent(output_path)
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(shortlist, f, ensure_ascii=False, indent=2)

    print(f"[v6] Shortlist saved to: {output_path}")

    # 6) Telegram (optional)
    sent = send_telegram_shortlist(shortlist, telegram_cfg, run_id=run_id)
    if sent:
        print("[v6] Telegram notification: OK (or disabled).")
    else:
        print("[v6] Telegram notification: FAILED (see logs above).")

    return {
        "run_id": run_id,
        "jobs_loaded": len(jobs),
        "shortlist_size": len(shortlist),
        "history_path": history_path,
        "output_path": output_path,
        "telegram_sent": sent,
    }


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description="Run v6 freelancing automation pipeline.")
    parser.add_argument(
        "--config",
        type=str,
        default="config/profile_v6.json",
        help="Path to v6 config JSON (default: config/profile_v6.json)",
    )

    args = parser.parse_args(argv)
    run_pipeline(args.config)


if __name__ == "__main__":  # pragma: no cover
    main()
