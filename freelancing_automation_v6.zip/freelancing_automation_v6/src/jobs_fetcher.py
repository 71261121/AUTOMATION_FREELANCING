"""
jobs_fetcher.py (v6)
--------------------

Responsible for turning a *source config* into a list of Job objects by
re‑using the existing JSON loader. It supports two modes:

1) local_json  – read from a JSON file on disk (default)
2) http_json   – fetch JSON from an HTTP endpoint and cache to disk, then load

This keeps all parsing in one place (jobs_loader.load_jobs) so that
validation & error behaviour stay identical to earlier versions.
"""

from __future__ import annotations

from typing import Any, Dict, List
import json
import pathlib

from .jobs_loader import load_jobs, JobLoadError

try:
    # requests is optional – only needed for http_json sources
    import requests  # type: ignore
except Exception:  # pragma: no cover - handled gracefully at runtime
    requests = None  # type: ignore


def _ensure_path(path_str: str) -> str:
    """
    Normalise a path string so that Termux + relative paths behave nicely.
    Returns a POSIX-style string path.
    """
    p = pathlib.Path(path_str).expanduser().resolve()
    return str(p)


def fetch_jobs_from_source(source_cfg: Dict[str, Any]) -> List[dict]:
    """
    High-level entry point used by the v6 pipeline.

    Parameters
    ----------
    source_cfg:
        {
          "type": "local_json" | "http_json",
          "path": "data/jobs_input_example.json",
          "http_url": "...",             # for http_json
          "http_timeout": 10,            # optional
          "cache_path": "data/http.json" # optional
        }

    Returns
    -------
    List[dict] – same schema as load_jobs(...)
    """
    source_type = (source_cfg.get("type") or "local_json").lower()

    if source_type == "local_json":
        path = source_cfg.get("path") or "data/jobs_input_example.json"
        path = _ensure_path(path)
        return load_jobs(path)

    if source_type == "http_json":
        if requests is None:
            raise RuntimeError(
                "http_json source requested but 'requests' is not installed. "
                "Run: pip install requests"
            )

        url = source_cfg.get("http_url") or source_cfg.get("url")
        if not url:
            raise ValueError("http_json source requires 'http_url' (or 'url') in config.")

        timeout = float(source_cfg.get("http_timeout") or 10)
        cache_path = source_cfg.get("cache_path") or "data/jobs_input_http.json"
        cache_path = _ensure_path(cache_path)

        resp = requests.get(url, timeout=timeout)
        resp.raise_for_status()
        payload = resp.json()

        # Expect either:
        #   {"jobs": [...]}  or  [...]
        if isinstance(payload, dict) and "jobs" in payload:
            jobs_payload = payload["jobs"]
        else:
            jobs_payload = payload

        # Cache the raw payload so the existing loader can validate & parse.
        pathlib.Path(cache_path).parent.mkdir(parents=True, exist_ok=True)
        with open(cache_path, "w", encoding="utf-8") as f:
            json.dump({"jobs": jobs_payload}, f, ensure_ascii=False, indent=2)

        return load_jobs(cache_path)

    raise ValueError(f"Unsupported source type: {source_type!r}")
