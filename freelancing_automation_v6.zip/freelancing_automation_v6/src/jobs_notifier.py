"""
jobs_notifier.py (v6)
---------------------

Responsible for *output side-effects* for the shortlist – right now:
Telegram notifications.

Design goals:
- If Telegram is not configured or fails, the core pipeline still succeeds.
- No Upwork / Guru credentials are handled here – only public job URLs.
"""

from __future__ import annotations

from typing import Any, Dict, List
import textwrap

try:
    import requests  # type: ignore
except Exception:  # pragma: no cover
    requests = None  # type: ignore


def build_shortlist_message(shortlist: List[dict], run_id: str) -> str:
    """
    Create a human-readable message for Telegram, staying under 4096 chars.
    """
    header = f"Freelancing shortlist (run {run_id}) — top {len(shortlist)} jobs"
    lines = [header, ""]

    for idx, job in enumerate(shortlist, start=1):
        title = job.get("title", "").strip() or "<no title>"
        platform = job.get("platform") or "unknown"
        budget = job.get("budget")
        currency = job.get("currency") or ""
        proposals = job.get("proposals")
        connects = job.get("connects_required") or job.get("connects") or "?"
        url = job.get("url") or ""
        score = job.get("score")

        block = [
            f"#{idx} [{platform}] {title}",
        ]
        if score is not None:
            block.append(f"Score: {score}")
        if budget is not None:
            block.append(f"Budget: {budget} {currency} | Proposals: {proposals} | Connects: {connects}")
        if url:
            block.append(f"URL: {url}")

        lines.append("
".join(block))
        lines.append("")  # blank line between jobs

    text = "
".join(lines).strip()

    # Telegram hard limit ~4096 chars – stay a bit under.
    max_len = 3900
    if len(text) > max_len:
        text = text[: max_len - 20] + "\n...(truncated)"

    return text


def send_telegram_shortlist(shortlist: List[dict], telegram_cfg: Dict[str, Any], run_id: str) -> bool:
    """
    Fire-and-forget Telegram notification.

    Returns
    -------
    bool – True if we *believe* the message went through, False otherwise.
    """
    enabled = bool(telegram_cfg.get("enabled"))
    if not enabled:
        # Explicitly disabled – treat as success so pipeline doesn't complain.
        return True

    if requests is None:
        # User enabled telegram but doesn't have requests – we fail soft.
        print("[telegram] 'requests' not installed; skipping send.")
        return False

    token = (telegram_cfg.get("bot_token") or "").strip()
    chat_id = (telegram_cfg.get("chat_id") or "").strip()
    if not token or not chat_id:
        print("[telegram] bot_token/chat_id not configured; skipping send.")
        return False

    text = build_shortlist_message(shortlist, run_id)
    api_url = f"https://api.telegram.org/bot{token}/sendMessage"

    try:
        resp = requests.post(
            api_url,
            json={"chat_id": chat_id, "text": text},
            timeout=float(telegram_cfg.get("timeout") or 10),
        )
    except Exception as exc:  # pragma: no cover - network error path
        print(f"[telegram] request failed: {exc}")
        return False

    try:
        data = resp.json()
    except Exception:
        print(f"[telegram] non-JSON response: status={resp.status_code}")
        return False

    if not data.get("ok"):
        print(f"[telegram] API error: {data}")
        return False

    return True
