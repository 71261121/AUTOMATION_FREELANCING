from __future__ import annotations

import json
from pathlib import Path
from typing import Iterable, List, Dict, Any

from .jobs_model import Job


class JobLoadError(Exception):
    """Raised when the input JSON cannot be parsed or is invalid."""


def _normalize_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        v = value.strip().lower()
        if v in {"true", "yes", "y", "1"}:
            return True
        if v in {"false", "no", "n", "0"}:
            return False
    if isinstance(value, (int, float)):
        return bool(value)
    return False


def load_jobs(path: str | Path) -> List[Job]:
    """Load jobs from a JSON file into Job objects.

    Expected JSON format: a list of dicts.
    Any unknown keys are stored in Job.raw.
    """
    p = Path(path)
    if not p.exists():
        raise JobLoadError(f"Input file does not exist: {p}")
    try:
        text = p.read_text(encoding="utf-8")
    except Exception as exc:  # pragma: no cover - very unlikely here
        raise JobLoadError(f"Failed to read file: {p}: {exc}") from exc

    try:
        data = json.loads(text)
    except json.JSONDecodeError as exc:
        raise JobLoadError(f"Invalid JSON in {p}: {exc}") from exc

    if not isinstance(data, list):
        raise JobLoadError("Top-level JSON must be a list of job objects")

    jobs: List[Job] = []
    for idx, item in enumerate(data):
        if not isinstance(item, dict):
            raise JobLoadError(f"Job at index {idx} is not an object")
        jobs.append(_job_from_dict(item, idx))
    return jobs


def _job_from_dict(d: Dict[str, Any], index: int) -> Job:
    """Convert a raw dict into a Job, being defensive about missing fields."""
    # Required-ish fields: we fall back to something but log in raw
    id_val = str(d.get("id") or f"job-{index}")
    platform = str(d.get("platform") or "unknown")
    title = str(d.get("title") or "(no title)")
    description = str(d.get("description") or "")

    budget_raw = d.get("budget")
    try:
        budget = float(budget_raw) if budget_raw not in (None, "") else None
    except (TypeError, ValueError):
        budget = None

    currency = d.get("currency") or None
    is_hourly = _normalize_bool(d.get("is_hourly", False))
    connects_required_raw = d.get("connects_required")
    try:
        connects_required = (
            int(connects_required_raw)
            if connects_required_raw not in (None, "")
            else None
        )
    except (TypeError, ValueError):
        connects_required = None

    proposals_raw = d.get("proposals")
    try:
        proposals = int(proposals_raw) if proposals_raw not in (None, "") else None
    except (TypeError, ValueError):
        proposals = None

    has_attachments = _normalize_bool(d.get("has_attachments", False))

    skills_val = d.get("skills") or []
    if isinstance(skills_val, str):
        # naive split on comma
        skills = [s.strip() for s in skills_val.split(",") if s.strip()]
    elif isinstance(skills_val, list):
        skills = [str(s).strip() for s in skills_val if str(s).strip()]
    else:
        skills = []

    # Store everything, but remove known keys from raw
    raw = dict(d)
    for key in [
        "id",
        "platform",
        "title",
        "description",
        "budget",
        "currency",
        "is_hourly",
        "connects_required",
        "proposals",
        "has_attachments",
        "skills",
    ]:
        raw.pop(key, None)

    return Job(
        id=id_val,
        platform=platform,
        title=title,
        description=description,
        budget=budget,
        currency=currency,
        is_hourly=is_hourly,
        connects_required=connects_required,
        proposals=proposals,
        has_attachments=has_attachments,
        skills=skills,
        raw=raw,
    )


def load_jobs_multi(paths: list[Path | str]) -> list[Job]:
    """
    Load jobs from multiple JSON files and return a single combined list.
    Files that fail will raise JobLoadError just like load_jobs.
    """
    all_jobs: list[Job] = []
    for p in paths:
        all_jobs.extend(load_jobs(p))
    return all_jobs
