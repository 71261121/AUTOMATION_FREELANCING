from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import List

from .jobs_loader import load_jobs, JobLoadError
from .jobs_scorer import score_jobs, sort_scored_jobs, ScoredJob


def format_job(sj: ScoredJob) -> str:
    j = sj.job
    lines = [
        f"Score: {sj.score:.1f}",
        f"Title: {j.title}",
        f"Platform: {j.platform}",
    ]
    if j.budget is not None:
        lines.append(f"Budget: {j.budget} {j.currency or ''}".strip())
    if j.proposals is not None:
        lines.append(f"Proposals: {j.proposals}")
    if j.connects_required is not None:
        lines.append(f"Connects required: {j.connects_required}")
    if j.has_attachments:
        lines.append("Attachments: yes")
    lines.append(f"ID: {j.id}")
    lines.append(f"URL: {j.raw.get('url', '(n/a)')}")
    lines.append("Reasons:")
    for r in sj.reasons:
        lines.append(f"  - {r}")
    return "\n".join(lines)


def main(argv: List[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Score and shortlist freelance jobs from a JSON file."
    )
    parser.add_argument(
        "--input",
        required=True,
        help="Path to jobs JSON file (list of job objects)",
    )
    parser.add_argument(
        "--output",
        required=False,
        default="output/shortlist.json",
        help="Where to save the shortlisted jobs JSON (default: output/shortlist.json)",
    )
    parser.add_argument(
        "--top-n",
        type=int,
        default=5,
        help="How many top jobs to keep in the shortlist (default: 5)",
    )
    args = parser.parse_args(argv)

    try:
        jobs = load_jobs(args.input)
    except JobLoadError as exc:
        print(f"[ERROR] {exc}")
        return 1

    scored = score_jobs(jobs)
    sorted_scored = sort_scored_jobs(scored)
    top_n = max(1, args.top_n)
    shortlisted = sorted_scored[:top_n]

    if not shortlisted:
        print("No jobs found in input file.")
        return 0

    print("========== SHORTLIST ==========")
    for idx, sj in enumerate(shortlisted, start=1):
        print(f"\n--- #{idx} ---")
        print(format_job(sj))

    # Save raw job dicts + score to JSON
    out_path = Path(args.output)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    to_dump = []
    for sj in shortlisted:
        j = sj.job
        item = dict(j.raw)
        # Put normalized fields up front for clarity
        item.update(
            {
                "id": j.id,
                "platform": j.platform,
                "title": j.title,
                "description": j.description,
                "budget": j.budget,
                "currency": j.currency,
                "is_hourly": j.is_hourly,
                "connects_required": j.connects_required,
                "proposals": j.proposals,
                "has_attachments": j.has_attachments,
                "skills": j.skills,
                "score": sj.score,
            }
        )
        to_dump.append(item)

    try:
        out_path.write_text(json.dumps(to_dump, indent=2), encoding="utf-8")
        print(f"\nShortlist saved to: {out_path}")
    except Exception as exc:  # pragma: no cover - unlikely
        print(f"[ERROR] Failed to write output file: {exc}")
        return 1

    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
