from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import json
from typing import List, Tuple

from .jobs_model import Job


CORE_KEYWORDS = [
    # PDF / forms
    "pdf",
    "fillable",
    "acrobat",
    "form",
    "form development",
    # Word / formatting
    "word",
    "docx",
    "formatting",
    "template",
    # PowerPoint / slides
    "powerpoint",
    "slide",
    "slides",
    "deck",
    "pitch deck",
    # General documents
    "proposal",
    "report",
    "layout",
]

RED_FLAG_KEYWORDS = [
    "exam",
    "test solution",
    "cheat",
    "solve my exam",
    "university assignment",
]


@dataclass
class ScoredJob:
    job: Job
    score: float
    reasons: List[str]


def score_job(job: Job) -> ScoredJob:
    """Score a single job based on simple transparent rules."""
    score = 0.0
    reasons: List[str] = []

    text = f"{job.title}\n{job.description}".lower()

    # 1) Attachments
    if job.has_attachments:
        score += 25
        reasons.append("+25: has attachment(s)")

    # 2) Fixed-price preference
    if job.is_fixed_price:
        score += 15
        reasons.append("+15: fixed-price job")

    # 3) Budget
    if job.budget is not None and job.budget > 0:
        # Scale 0–100 USD => 0–20 points, clamp at 20
        capped = min(job.budget, 100.0)
        budget_points = (capped / 100.0) * 20.0
        score += budget_points
        reasons.append(f"+{budget_points:.1f}: budget-based score (budget={job.budget})")
    else:
        reasons.append("+0: no budget specified")

    # 4) Competition (proposals)
    if job.proposals is not None:
        if 5 <= job.proposals <= 20:
            score += 15
            reasons.append("+15: healthy competition (5-20 proposals)")
        elif job.proposals > 40:
            score -= 15
            reasons.append("-15: too many proposals (>40)")
        else:
            reasons.append("+0: neutral proposal count")
    else:
        reasons.append("+0: proposals unknown")

    # 5) Connects required (light penalty for 16+)
    if job.connects_required is not None and job.connects_required >= 16:
        score -= 5
        reasons.append("-5: high connects required (>=16)")

    # 6) Skill keyword match
    kw_hits = 0
    for kw in CORE_KEYWORDS:
        if kw in text:
            kw_hits += 1
    if kw_hits:
        kw_points = 10 + (kw_hits - 1) * 2  # e.g. 1 hit=10, 3 hits=14...
        score += kw_points
        reasons.append(f"+{kw_points}: matches your core skills ({kw_hits} hits)")
    else:
        reasons.append("+0: no strong core-skill keywords")

    # 7) Red flags
    for bad in RED_FLAG_KEYWORDS:
        if bad in text:
            score -= 30
            reasons.append(f"-30: red-flag keyword: '{bad}'")

    # 8) Seriousness: attachment + budget
    if job.has_attachments and job.has_budget:
        score += 5
        reasons.append("+5: attachment + non-zero budget => more serious client")

    return ScoredJob(job=job, score=score, reasons=reasons)


def score_jobs(jobs: List[Job]) -> List[ScoredJob]:
    return [score_job(j) for j in jobs]


def sort_scored_jobs(scored: List[ScoredJob]) -> List[ScoredJob]:
    """Sort jobs: highest score first, then by budget descending, then title."""
    return sorted(
        scored,
        key=lambda sj: (
            -sj.score,
            -(sj.job.budget or 0.0),
            sj.job.title.lower(),
        ),
    )
