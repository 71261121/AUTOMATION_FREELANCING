from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional, Dict, Any


@dataclass
class Job:
    """Normalized representation of a freelance job posting.

    This keeps V1 simple but future-proof:
    - You can add more fields later without breaking the scorer.
    - Unknown keys are kept in `raw` so nothing is lost.
    """

    id: str
    platform: str
    title: str
    description: str

    budget: Optional[float] = None
    currency: Optional[str] = None
    is_hourly: bool = False

    connects_required: Optional[int] = None
    proposals: Optional[int] = None
    has_attachments: bool = False

    skills: List[str] = None

    # Raw dict for any extra fields you may want later
    raw: Dict[str, Any] = None

    def __post_init__(self) -> None:
        if self.skills is None:
            self.skills = []
        if self.raw is None:
            self.raw = {}

        # Normalize simple things
        if self.currency:
            self.currency = self.currency.upper()

        # Ensure strings are stripped
        self.id = self.id.strip()
        self.platform = self.platform.strip()
        self.title = self.title.strip()
        self.description = self.description.strip()

    @property
    def is_fixed_price(self) -> bool:
        return not self.is_hourly

    @property
    def has_budget(self) -> bool:
        return self.budget is not None and self.budget > 0
