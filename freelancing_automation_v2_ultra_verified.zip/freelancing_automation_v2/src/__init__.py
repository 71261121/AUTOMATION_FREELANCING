"""Core package for freelancing automation v2."""
