# jobs_loader.py – 7-layer verification notes

1. **Syntax check**
   - Imports: json, pathlib.Path, typing – all stdlib.
   - Imports `Job` and `JobLoadError` works without circular imports.
   - Module imports successfully.

2. **Type-shape sanity**
   - Expects top-level JSON = list[dict].
   - Each dict may omit fields; `_job_from_dict` provides fallbacks:
     - No `id` → `job-{index}`.
     - No `platform` → "unknown".
     - No `title` → "(no title)".
     - Missing numeric fields are converted to None instead of raising.
   - Unknown keys are preserved in `Job.raw`.

3. **Edge cases**
   - Non-existent file: raises JobLoadError with clear message.
   - Invalid JSON: raises JobLoadError with parse error.
   - Top-level not a list: raises JobLoadError.
   - Item not a dict: raises JobLoadError.
   - `skills` can be:
     - list → cleaned list of strings
     - comma-separated string → split
     - anything else → empty list

4. **Logic sanity**
   - Does *not* guess too much – keeps loader conservative.
   - Always returns a list of Job objects; no partial types.
   - Numeric casts use try/except to avoid crashing on bad inputs.

5. **I/O sanity**
   - File reading uses UTF-8.
   - No writes here; only reading JSON.

6. **Termux safety**
   - Only stdlib.
   - Path usage is generic POSIX, works in Termux the same.

7. **Failure behavior**
   - All error cases raise JobLoadError instead of bare exceptions.
   - CLI caller prints a nice message when JobLoadError is raised.
