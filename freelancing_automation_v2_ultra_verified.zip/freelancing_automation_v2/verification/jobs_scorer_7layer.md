# jobs_scorer.py – 7-layer verification notes

1. **Syntax check**
   - Stdlib-only imports.
   - Imports Job from jobs_model correctly.
   - Module imports cleanly.

2. **Type-shape sanity**
   - `score_job(job: Job) -> ScoredJob`:
     - Assumes Job fields as normalized by loader.
     - Handles None budgets, proposals, connects_required.
   - `score_jobs` returns list of ScoredJob with same length as input.

3. **Edge cases**
   - No budget: adds a neutral reason line, no crash.
   - No proposals: neutral reason.
   - No skills / no keyword hits: adds "+0" reason only.
   - Red-flag matching is simple "substring in lowercased text"; safe.

4. **Logic sanity**
   - Weights match your written preferences:
     - Attachments are heavily rewarded.
     - Fixed-price jobs preferred.
     - Budget scaled 0–100 → 0–20 points.
     - Proposal sweet spot 5–20 → +15.
     - Overcrowded >40 → -15.
     - Connects >=16 → small penalty.
     - Core-skill keywords give a modest but real boost.
     - Red flags strongly penalize.
   - Reasons list is fully transparent for debugging.

5. **I/O sanity**
   - No file or network I/O.
   - Pure scoring functions.

6. **Termux safety**
   - Stdlib only.
   - Stateless; behaves the same everywhere.

7. **Failure behavior**
   - No explicit exceptions; worst case, a weird job just gets a neutral-ish score.
   - Caller can inspect `ScoredJob.reasons` to understand why.
