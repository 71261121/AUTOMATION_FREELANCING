# jobs_model.py – 7-layer verification notes

1. **Syntax check**
   - Imports: dataclasses, typing – all from standard library.
   - File imports cleanly under Python 3.10+.
   - No side effects on import.

2. **Type-shape sanity**
   - `Job` dataclass fields:
     - id, platform, title, description: always normalized to stripped strings.
     - budget: Optional[float], can be None or >0.
     - currency: normalized to upper-case when present.
     - is_hourly: bool.
     - connects_required, proposals: Optional[int].
     - has_attachments: bool.
     - skills: List[str] but defaults to [] in __post_init__.
     - raw: Dict[str, Any] defaulted to {} in __post_init__.
   - Computed properties:
     - `is_fixed_price` is simply `not is_hourly`.
     - `has_budget` is True only when budget is non-null and > 0.

3. **Edge cases**
   - Missing skills & raw: __post_init__ sets them to empty list/dict.
   - Empty strings for id/platform/title/description get stripped; upstream loader ensures they are non-empty fallback values.
   - Currency may be None; consumers must handle that (CLI does).

4. **Logic sanity**
   - This module does not contain scoring logic – just normalization.
   - It is safe to add fields later without breaking other modules (new fields will just exist on Job).

5. **I/O sanity**
   - No file or network I/O in this module.
   - Safe to import from anywhere (Termux, desktop, etc.).

6. **Termux safety**
   - Only uses stdlib.
   - No OS-specific behavior.

7. **Failure behavior**
   - All potential failures are upstream (e.g. when constructing Job with bad types).
   - Loader is responsible for defensive casting; this object assumes already-sanitized inputs.
