# jobs_shortlist_cli.py – 7-layer verification notes

1. **Syntax check**
   - Uses argparse, json, pathlib – all stdlib.
   - Imports from jobs_loader and jobs_scorer correctly.
   - `main()` callable without side effects.

2. **Type-shape sanity**
   - `--input` and `--output` arguments are plain strings.
   - `--top-n` is coerced to int; negative values are clamped via `max(1, top_n)`.
   - Shortlist structure written to JSON is a list of dicts (safe for reuse).

3. **Edge cases**
   - Missing input file → JobLoadError → printed clean `[ERROR]` message, exit code 1.
   - Empty list of jobs → prints "No jobs found" and exits 0.
   - Output directory missing → created with `mkdir(parents=True, exist_ok=True)`.

4. **Logic sanity**
   - Keeps CLI focused on a single responsibility:
     - Load → Score → Sort → Print → Save.
   - Output JSON includes:
     - Normalized fields and original `raw` extra fields.
     - `score` so you can inspect ranking later.

5. **I/O sanity**
   - Reads only the specified input file.
   - Writes only to the specified output file.
   - All I/O is UTF-8 text, portable.

6. **Termux safety**
   - No absolute paths, no OS-specific calls.
   - Works from any current working directory (CWD), as long as you pass correct `--input`.

7. **Failure behavior**
   - Any loader-related problem → friendly error, no stacktrace.
   - Output writing is wrapped; failure prints error & exit code 1.
