from __future__ import annotations

import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.jobs_loader import load_jobs, JobLoadError
from src.jobs_model import Job


def test_load_jobs_basic_structure(tmp_path):
    """Loader should read a minimal JSON list and return Job objects."""
    data = [
        {
            "id": "job-1",
            "platform": "upwork",
            "title": "Test job",
            "description": "Some description",
        }
    ]
    input_file = tmp_path / "jobs.json"
    input_file.write_text(json.dumps(data), encoding="utf-8")

    jobs = load_jobs(input_file)
    assert len(jobs) == 1
    job = jobs[0]
    assert isinstance(job, Job)
    assert job.platform == "upwork"
    assert job.id == "job-1"
    assert job.title == "Test job"
    assert job.description == "Some description"


def test_load_jobs_missing_file_raises(tmp_path):
    missing = tmp_path / "missing.json"
    try:
        load_jobs(missing)
    except JobLoadError as e:
        # message is user-friendly, just check key phrase
        assert "does not exist" in str(e)
    else:
        raise AssertionError("JobLoadError not raised for missing file")
