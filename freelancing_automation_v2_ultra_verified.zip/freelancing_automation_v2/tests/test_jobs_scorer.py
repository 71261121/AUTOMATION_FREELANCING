from __future__ import annotations

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.jobs_scorer import score_job
from src.jobs_model import Job


def _make_job(**overrides) -> Job:
    base = {
        "id": "up-1",
        "platform": "upwork",
        "title": "Convert PDF to fillable form",
        "description": "Need PDF / Word / form expert",
        "budget": 50.0,
        "currency": "USD",
        "is_hourly": False,
        "connects_required": 8,
        "proposals": 10,
        "has_attachments": True,
        "skills": ["PDF", "Word"],
    }
    base.update(overrides)
    return Job(**base)


def test_score_job_core_positive():
    job = _make_job()
    scored = score_job(job)
    assert scored.score > 0
    assert scored.reasons
    assert any("fixed-price" in r for r in scored.reasons)


def test_score_job_red_flag_penalised():
    normal = score_job(_make_job())
    exam_job = score_job(_make_job(title="Help with my university exam"))
    assert exam_job.score < normal.score
    assert any("red-flag" in r.lower() for r in exam_job.reasons)
